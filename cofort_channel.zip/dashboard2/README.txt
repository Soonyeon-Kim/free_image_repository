Dashboard 2 (유입연도 × 채널 심층 분석) 이미지 패키지

[background] 1897×1290
 dashboard2_bg_1897x1290.png / .svg(피그마)
 제목 영역 y 0–60 · 행 y 60 / 470 / 880 · 높이 390 · 행 간격 20 · 하단 여백 20
 좌 열 x16 w760 · 우 열 x784 w1097 · 열 간격 8
 A(16,60) B(784,60) C(16,470) D(784,470) F(16,880) E(784,880)
 헤더 36px · A·B #1F5F8B · C·D #D2644B · E·F #5E8A2E

[nav-buttons] 80×30 · 대시보드 이동 (제목 영역에 배치)
 nav_1_overview = 전체현황 · nav_2_cross = 교차분석 · nav_3_elapsed = 경과분석
 활성: 흰 바탕 #FFFFFF / 글자 #006666
 비활성: 바탕 #005C5C / 테두리 #5FB8B8 / 글자 #E3F2F2

[buttons] 112×28 · A·B 공용 지표 버튼
 AB_metric_(active|inactive)_(accounts|asset|profit) = 계좌수 · 자산 · 수익

[toggles] 반쪽 100×30 · A 좌당 지표 토글 (왼쪽+오른쪽을 붙여 사용)
 A_toggle_left_per-account-profit = 좌당 수익 · A_toggle_right_per-account-asset = 좌당 자산

[C_labels] C 산점도용 투명 PNG
 quadrant_* 220×24 (사분면 라벨 4개, 오른쪽 사분면은 오른쪽 정렬)
 legend_point-size 170×70 (점 범례 설명)
